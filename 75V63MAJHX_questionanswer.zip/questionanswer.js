let change = document.getElementById("click");

function question() {
    let h1 = document.createElement("h1");
    h1.textContext = "Hello";
    h1.classList.add('heading');
    document.body.appendChild(h1);
}